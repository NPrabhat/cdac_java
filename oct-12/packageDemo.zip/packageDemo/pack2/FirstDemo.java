package packageDemo.pack2;
public class FirstDemo {
    int x=100;
    
    public void show(){
        System.out.println("From Pak2 "+x);
    }
}
