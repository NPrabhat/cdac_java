package packageDemo.pack2;
public class SecondDemo extends packageDemo.pack1.FirstDemo {
     int y=100;
    
    public void show1(){
        System.out.println("From Pak2 "+(y+x));
    }
}
