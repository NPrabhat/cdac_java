package packageDemo.pack1;
public class FirstDemo {
    protected int x=10;
    
    public static void show(){
        System.out.println("From Pak1 ");
    }
}
