package packageDemo.pack1;

public class ThirdDemo {
    void accsessProtected(){
    FirstDemo f=new FirstDemo();
        System.out.println(f.x);
    }
}
